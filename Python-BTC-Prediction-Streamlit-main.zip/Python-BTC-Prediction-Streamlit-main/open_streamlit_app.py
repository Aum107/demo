#Force automatic rebuild of the Streamlit app

import webbrowser
import time

url = "https://python-btc-prediction.streamlit.app/"
webbrowser.open(url)

time.sleep(3)